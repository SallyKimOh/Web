            <footer>
                <p>&copy; 2017 CST8285. All Rights Reserved.</p>
            </footer>
